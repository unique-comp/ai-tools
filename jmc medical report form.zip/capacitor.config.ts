import type { CapacitorConfig } from "@capacitor/cli";

/**
 * Two supported Android setups:
 *
 * 1) Standalone APK (recommended): `npm run build`, then
 *    `npx cap add android`, `npx cap sync android` and build with Gradle or
 *    Android Studio. The certificate is bundled inside the APK and works
 *    fully offline.
 *
 * 2) APK + Termux backend: start `node scripts/serve.mjs` in Termux and
 *    uncomment the `server` block below so the WebView loads the local server
 *    (rebuild the APK after changing it).
 */
const config: CapacitorConfig = {
  appId: "com.jubailmedicare.certificate",
  appName: "JMC Certificate",
  webDir: "dist",
  backgroundColor: "#eceef1",
  // server: {
  //   url: "http://127.0.0.1:4173",
  //   cleartext: true,
  //   androidScheme: "http",
  // },
  android: {
    allowMixedContent: false,
    backgroundColor: "#eceef1",
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 400,
      backgroundColor: "#080a3e",
      androidSplashResourceName: "splash",
      androidScaleType: "CENTER_CROP",
    },
  },
};

export default config;
