export type CertificateData = {
  recipient: string;
  date: string;
  fileNo: string;
  category: string;
  bloodGroup: string;
  name: string;
  nationality: string;
  age: string;
  sex: string;
  passport: string;
  dateOfBirth: string;
  sponsor: string;
  jobDescription: string;
  city: string;
  height: string;
  weight: string;
  pulse: string;
  bloodPressure: string;
  temperature: string;
  lungs: string;
  cardiovascular: string;
  neurological: string;
  nearLeft: string;
  nearRight: string;
  farLeft: string;
  farRight: string;
  hearingLeft: string;
  hearingRight: string;
  generalHealth: string;
  covidSymptoms: string;
  appearance: string;
  chronicDisease: string;
  comments: string;
  validUntil: string;
  physician: string;
  director: string;
};

export const initialCertificate: CertificateData = {
  recipient: "",
  date: "20/02/2026 11:00 AM",
  fileNo: "A5401311",
  category: "NEW",
  bloodGroup: "A+VE",
  name: "SHEK TIPU JULFE",
  nationality: "INDIA",
  age: "34 Y",
  sex: "M",
  passport: "2585759463",
  dateOfBirth: "03/09/1991",
  sponsor: "CASH",
  jobDescription: "",
  city: "JUBAIL",
  height: "170",
  weight: "71",
  pulse: "72 b/min",
  bloodPressure: "110/70mmHg",
  temperature: "36.8\u00b0C",
  lungs: "NORMAL",
  cardiovascular: "NORMAL",
  neurological: "NORMAL",
  nearLeft: "6/6=NORMAL",
  nearRight: "6/6=NORMAL",
  farLeft: "6/6=NORMAL",
  farRight: "6/6=NORMAL",
  hearingLeft: "NORMAL",
  hearingRight: "NORMAL",
  generalHealth: "NO COUGH-NO FEVER-NO BREATHING DIFFICULTY",
  covidSymptoms: "NO COVID-19 SYMPTOMS",
  appearance: "NORMAL",
  chronicDisease: "NIL",
  comments: "FIT FOR WORK",
  validUntil: "10/07/2026",
  physician: "DR. SHAHID HUSSAIN ()",
  director: "DR. SAEED ABDUL KHALIQ",
};

export const certificateStorageKey = "jubail-medical-certificate-v1";

const clean = (value: string, placeholder = "-") => {
  const normalized = value.replace(/\s+/g, " ").trim();
  return normalized.length > 0 ? normalized : placeholder;
};

/**
 * Builds the QR payload straight from the certificate record, so the code
 * always reflects the details currently shown on the page.
 */
export function encodeCertificateQr(data: CertificateData): string {
  const lines = [
    "JUBAIL MEDICARE CO. / MEDICAL CHECK UP",
    [
      `FILE ${clean(data.fileNo)}`,
      `DATE ${clean(data.date)}`,
      `TO ${clean(data.recipient)}`,
      `CAT ${clean(data.category)}`,
      `BLOOD ${clean(data.bloodGroup)}`,
    ].join("|"),
    [
      clean(data.name),
      clean(data.nationality),
      `AGE ${clean(data.age)}`,
      `SEX ${clean(data.sex)}`,
      `PASS ${clean(data.passport)}`,
      `DOB ${clean(data.dateOfBirth)}`,
    ].join("|"),
    [
      `EMP ${clean(data.sponsor)}`,
      `JOB ${clean(data.jobDescription)}`,
      `CITY ${clean(data.city)}`,
    ].join("|"),
    [
      `H ${clean(data.height)}cm`,
      `W ${clean(data.weight)}kg`,
      `PULSE ${clean(data.pulse)}`,
      `BP ${clean(data.bloodPressure)}`,
      `TEMP ${clean(data.temperature)}`,
    ].join("|"),
    [
      `LUNGS ${clean(data.lungs)}`,
      `CARDIO ${clean(data.cardiovascular)}`,
      `NEURO ${clean(data.neurological)}`,
    ].join("|"),
    [
      `NEAR L ${clean(data.nearLeft)} R ${clean(data.nearRight)}`,
      `FAR L ${clean(data.farLeft)} R ${clean(data.farRight)}`,
    ].join("|"),
    `HEARING L ${clean(data.hearingLeft)} R ${clean(data.hearingRight)}`,
    [
      `HEALTH ${clean(data.generalHealth)}`,
      `COVID ${clean(data.covidSymptoms)}`,
      `LOOK ${clean(data.appearance)}`,
      `CHRONIC ${clean(data.chronicDisease)}`,
      `NOTE ${clean(data.comments)}`,
    ].join("|"),
    `VALID ${clean(data.validUntil)}`,
    `DR: ${clean(data.physician)} / DIR: ${clean(data.director)}`,
  ];

  return lines.join("\n");
}