const clinicArabic = "\u0645\u062c\u0645\u0639 \u0631\u0639\u0627\u064a\u0629 \u0627\u0644\u062c\u0628\u064a\u0644 \u0627\u0644\u0637\u0628\u064a";
const leftDoctorArabic = "\u062f. \u0634\u0647\u064a\u062f \u062d\u0633\u064a\u0646";
const rightDoctorArabic = "\u062f. \u0633\u0639\u064a\u062f \u0639\u0628\u062f \u0627\u0644\u062e\u0627\u0644\u0642";

export default function SealArtwork() {
  return (
    <svg
      className="seal-artwork"
      viewBox="0 0 1240 1755"
      width="1240"
      height="1755"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        <path id="round-seal-top" d="M 466 1516 A 102 102 0 0 1 670 1516" />
        <path id="round-seal-bottom" d="M 472 1545 A 99 99 0 0 0 666 1545" />
      </defs>

      <g fill="none" stroke="#0732aa" strokeLinecap="round" strokeLinejoin="round">
        <g opacity="0.88" transform="rotate(-2 570 1512)">
          <circle cx="570" cy="1512" r="113" strokeWidth="2.5" />
          <circle cx="570" cy="1512" r="108" strokeWidth="1.4" />
          <circle cx="570" cy="1512" r="74" strokeWidth="1.3" />
          <circle cx="570" cy="1512" r="48" fill="#0835b2" strokeWidth="1.5" />
          <text
            fill="#0732aa"
            stroke="none"
            fontSize="23"
            fontWeight="700"
            fontFamily="Arial, sans-serif"
            letterSpacing=".4"
          >
            <textPath href="#round-seal-top" startOffset="50%" textAnchor="middle">
              {clinicArabic}
            </textPath>
          </text>
          <text
            fill="#0732aa"
            stroke="none"
            fontSize="19"
            fontWeight="700"
            fontFamily="Arial, sans-serif"
            letterSpacing="-.5"
          >
            <textPath href="#round-seal-bottom" startOffset="50%" textAnchor="middle">
              JUBAIL MEDICARE COMPLEX
            </textPath>
          </text>
          <text x="570" y="1464" fill="#0732aa" stroke="none" textAnchor="middle" fontSize="20" fontWeight="700">
            {"\u0627\u0644\u062c\u0628\u064a\u0644"}
          </text>
          <text x="570" y="1550" fill="#0732aa" stroke="none" textAnchor="middle" fontSize="20" fontWeight="700">
            Jubail
          </text>
          <text x="570" y="1533" fill="#fff" stroke="none" textAnchor="middle" fontFamily="Georgia, serif" fontStyle="italic" fontWeight="700" fontSize="59">
            M
          </text>
          <text x="592" y="1541" fill="#fff" stroke="none" fontFamily="Arial, sans-serif" fontSize="11" fontWeight="700">
            JMC
          </text>
          <circle cx="485" cy="1509" r="17" fill="#0732aa" strokeWidth="1" />
          <circle cx="654" cy="1509" r="17" fill="#0732aa" strokeWidth="1" />
          <text x="485" y="1516" fill="#fff" stroke="none" textAnchor="middle" fontFamily="Arial, sans-serif" fontSize="16" fontWeight="700">
            04
          </text>
          <text x="654" y="1516" fill="#fff" stroke="none" textAnchor="middle" fontFamily="Arial, sans-serif" fontSize="17" fontWeight="700">
            *
          </text>
        </g>

        <g transform="translate(80 1474) rotate(-1 150 85)" opacity="0.86">
          <path d="M 29 11 L 274 8 Q 286 8 287 20 L 286 153 Q 285 168 271 169 L 22 169 Q 4 169 4 152 L 4 37 Q 5 17 29 11 Z" strokeWidth="2.2" />
          <path d="M 23 18 L 274 15 L 279 150 Q 279 159 271 160 L 14 160 L 13 35 Q 13 21 23 18 Z" strokeWidth="1.2" opacity=".7" />
          <path d="M 17 62 L 278 60 M 20 114 L 281 112" strokeWidth="1.2" />
          <circle cx="50" cy="42" r="28" fill="#0732aa" strokeWidth="1.5" />
          <circle cx="50" cy="42" r="23" stroke="#fff" strokeWidth=".8" />
          <text x="50" y="53" fill="#fff" stroke="none" fontFamily="Georgia, serif" fontStyle="italic" fontSize="35" fontWeight="700" textAnchor="middle">M</text>
          <text x="50" y="59" fill="#fff" stroke="none" fontFamily="Arial, sans-serif" fontSize="7" textAnchor="middle">JMC</text>
          <text x="91" y="30" fill="#0732aa" stroke="none" fontFamily="Arial, sans-serif" fontSize="16" fontWeight="700">{clinicArabic}</text>
          <text x="91" y="48" fill="#0732aa" stroke="none" fontFamily="Arial, sans-serif" fontSize="13" fontWeight="700">JUBAIL MEDICARE COMPLEX</text>
          <text x="146" y="84" fill="#0732aa" stroke="none" textAnchor="middle" fontFamily="Arial, sans-serif" fontWeight="700" fontSize="17">{leftDoctorArabic}</text>
          <text x="145" y="104" fill="#0732aa" stroke="none" textAnchor="middle" fontFamily="Arial, sans-serif" fontWeight="700" fontSize="14">DR. SHAHID HUSSAIN</text>
          <text x="145" y="134" fill="#0732aa" stroke="none" textAnchor="middle" fontFamily="Arial, sans-serif" fontSize="14" fontWeight="700">General Practitioner</text>
          <text x="145" y="153" fill="#0732aa" stroke="none" textAnchor="middle" fontFamily="Arial, sans-serif" fontSize="12" fontWeight="700">Lic. No.: 3800133517</text>
          <path d="M 18 100 C 67 91 115 108 169 92 C 195 85 238 75 307 59 M 103 136 C 142 110 185 72 231 30 C 237 26 227 38 218 51 C 205 75 201 117 248 143 M 144 150 C 133 125 155 91 202 73 C 217 67 244 71 262 78" strokeWidth="2.4" opacity=".95" />
        </g>

        <g transform="translate(772 1454) rotate(-1.7 166 92)" opacity="0.83">
          <path d="M 28 14 L 310 12 Q 326 13 326 29 L 325 183 L 8 183 L 7 42 Q 8 19 28 14 Z" strokeWidth="2" />
          <path d="M 16 28 L 316 23 L 316 170 L 16 173 Z M 15 67 L 316 64 M 16 113 L 316 110" strokeWidth="1.2" opacity=".8" />
          <circle cx="54" cy="44" r="31" fill="#0732aa" strokeWidth="1.3" />
          <circle cx="54" cy="44" r="24" stroke="#fff" strokeWidth=".9" />
          <text x="54" y="56" fill="#fff" stroke="none" fontFamily="Georgia, serif" fontStyle="italic" fontSize="37" fontWeight="700" textAnchor="middle">M</text>
          <text x="54" y="62" fill="#fff" stroke="none" fontFamily="Arial, sans-serif" fontSize="8" textAnchor="middle">JMC</text>
          <text x="105" y="36" fill="#0732aa" stroke="none" fontFamily="Arial, sans-serif" fontSize="16" fontWeight="700">{clinicArabic}</text>
          <text x="105" y="57" fill="#0732aa" stroke="none" fontFamily="Arial, sans-serif" fontSize="14" fontWeight="700">JUBAIL MEDICARE COMPLEX</text>
          <text x="171" y="90" fill="#0732aa" stroke="none" textAnchor="middle" fontFamily="Arial, sans-serif" fontSize="16" fontWeight="700">{rightDoctorArabic}</text>
          <text x="169" y="108" fill="#0732aa" stroke="none" textAnchor="middle" fontFamily="Arial, sans-serif" fontSize="16" fontWeight="700">Dr. Saaid A.S. Abdulkhaliq</text>
          <text x="169" y="140" fill="#0732aa" stroke="none" textAnchor="middle" fontFamily="Arial, sans-serif" fontSize="16" fontWeight="700">General Surgery</text>
          <text x="169" y="164" fill="#0732aa" stroke="none" textAnchor="middle" fontFamily="Arial, sans-serif" fontSize="12" fontWeight="700">Lic. No.: 3800202834</text>
          <path d="M 115 130 C 177 127 239 107 324 91 C 355 86 389 96 377 105 C 357 117 325 113 309 114 M -30 145 C 68 145 137 136 211 125 C 264 117 323 119 393 141 M 291 71 C 268 91 265 114 286 134 C 295 143 313 145 326 143" strokeWidth="2.5" />
        </g>
      </g>
    </svg>
  );
}