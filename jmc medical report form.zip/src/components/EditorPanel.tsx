import type { CertificateData } from "../certificate-data";

type EditorPanelProps = {
  data: CertificateData;
  onChange: (field: keyof CertificateData, value: string) => void;
  onClose: () => void;
  onPrint: () => void;
  onReset: () => void;
};

type EditorField = {
  field: keyof CertificateData;
  label: string;
  full?: boolean;
};

const recordFields: EditorField[] = [
  { field: "recipient", label: "To", full: true },
  { field: "date", label: "Certificate date", full: true },
  { field: "fileNo", label: "File number" },
  { field: "category", label: "Category" },
  { field: "name", label: "Patient name", full: true },
  { field: "nationality", label: "Nationality" },
  { field: "age", label: "Age" },
  { field: "sex", label: "Sex" },
  { field: "bloodGroup", label: "Blood group" },
  { field: "passport", label: "Passport / Iqama", full: true },
  { field: "dateOfBirth", label: "Date of birth", full: true },
];

const employmentFields: EditorField[] = [
  { field: "sponsor", label: "Sponsor / company", full: true },
  { field: "jobDescription", label: "Job description", full: true },
  { field: "city", label: "City", full: true },
];

const examinationFields: EditorField[] = [
  { field: "pulse", label: "Pulse" },
  { field: "bloodPressure", label: "Blood pressure" },
  { field: "temperature", label: "Temperature" },
  { field: "lungs", label: "Lungs & chest", full: true },
  { field: "cardiovascular", label: "Cardiovascular", full: true },
  { field: "neurological", label: "Neurological", full: true },
  { field: "nearLeft", label: "Near vision, left" },
  { field: "nearRight", label: "Near vision, right" },
  { field: "farLeft", label: "Far vision, left" },
  { field: "farRight", label: "Far vision, right" },
  { field: "hearingLeft", label: "Hearing, left" },
  { field: "hearingRight", label: "Hearing, right" },
];

const assessmentFields: EditorField[] = [
  { field: "generalHealth", label: "General health condition", full: true },
  { field: "covidSymptoms", label: "COVID-19 symptoms", full: true },
  { field: "appearance", label: "Appearance", full: true },
  { field: "chronicDisease", label: "Chronic diseases", full: true },
  { field: "comments", label: "Additional comments", full: true },
  { field: "validUntil", label: "Valid until", full: true },
  { field: "physician", label: "Attending physician", full: true },
  { field: "director", label: "Medical director", full: true },
];

export default function EditorPanel({ data, onChange, onClose, onPrint, onReset }: EditorPanelProps) {
  const renderField = ({ field, label, full }: EditorField) => (
    <label className={`editor-field${full ? " editor-field-full" : ""}`} key={field}>
      <span>{label}</span>
      <input
        type="text"
        value={data[field]}
        onChange={(event) => onChange(field, event.target.value)}
        autoComplete="off"
        spellCheck={false}
      />
    </label>
  );

  return (
    <>
      <button className="editor-backdrop" aria-label="Close editor" onClick={onClose} />
      <aside className="editor-panel" role="dialog" aria-modal="true" aria-labelledby="editor-title">
        <div className="editor-header">
          <div>
            <span className="editor-kicker">JUBAIL MEDICARE CO.</span>
            <h2 id="editor-title">Edit certificate</h2>
            <p>Changes appear on the document instantly.</p>
          </div>
          <button type="button" className="icon-button close-editor" onClick={onClose} aria-label="Close editor">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
              <path d="M5 5l14 14M19 5L5 19" strokeLinecap="round" />
            </svg>
          </button>
        </div>

        <div className="editor-body">
          <section className="editor-measurements" aria-labelledby="measurements-title">
            <div className="editor-section-heading">
              <h3 id="measurements-title">Measurements</h3>
              <span>01 / 05</span>
            </div>
            <p>Update height and weight here, or select either field on the page.</p>
            <div className="measurement-grid">
              <label className="editor-field measurement-field">
                <span>Height</span>
                <span className="input-with-unit">
                  <input
                    type="number"
                    min="0"
                    step="any"
                    inputMode="decimal"
                    value={data.height}
                    onChange={(event) => onChange("height", event.target.value)}
                    aria-label="Height in centimeters"
                  />
                  <span>cm</span>
                </span>
              </label>
              <label className="editor-field measurement-field">
                <span>Weight</span>
                <span className="input-with-unit">
                  <input
                    type="number"
                    min="0"
                    step="any"
                    inputMode="decimal"
                    value={data.weight}
                    onChange={(event) => onChange("weight", event.target.value)}
                    aria-label="Weight in kilograms"
                  />
                  <span>kg</span>
                </span>
              </label>
            </div>
          </section>

          <details className="editor-details">
            <summary><span>Patient & certificate</span><span className="detail-number">02 / 05</span></summary>
            <div className="editor-field-grid">{recordFields.map(renderField)}</div>
          </details>
          <details className="editor-details">
            <summary><span>Employment</span><span className="detail-number">03 / 05</span></summary>
            <div className="editor-field-grid">{employmentFields.map(renderField)}</div>
          </details>
          <details className="editor-details">
            <summary><span>Examination</span><span className="detail-number">04 / 05</span></summary>
            <div className="editor-field-grid">{examinationFields.map(renderField)}</div>
          </details>
          <details className="editor-details">
            <summary><span>Assessment & sign-off</span><span className="detail-number">05 / 05</span></summary>
            <div className="editor-field-grid">{assessmentFields.map(renderField)}</div>
          </details>

          <p className="editor-save-note">
            <span className="save-dot" aria-hidden="true" />
            Saved automatically in this browser
          </p>
        </div>

        <div className="editor-footer">
          <button type="button" className="print-action" onClick={onPrint}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
              <path d="M6 9V3h12v6M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" strokeLinejoin="round" />
              <path d="M6 15h12v6H6zM18 12h.01" strokeLinecap="round" />
            </svg>
            Print / Save PDF
          </button>
          <button type="button" className="reset-action" onClick={onReset}>Restore sample details</button>
        </div>
      </aside>
    </>
  );
}