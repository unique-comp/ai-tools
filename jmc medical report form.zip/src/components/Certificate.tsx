import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { QRCodeSVG } from "qrcode.react";
import { encodeCertificateQr, type CertificateData } from "../certificate-data";
import { brandArabic, brandEnglish, brandSymbol } from "../assets/logoAssets";
import SealArtwork from "./SealArtwork";

type CertificateProps = {
  data: CertificateData;
  onChange: (field: keyof CertificateData, value: string) => void;
};

type BoxOptions = {
  height?: number;
  fontSize?: number;
  center?: boolean;
};

const footerArabic =
  "\u0633. \u062a \u0662\u0660\u0665\u0665\u0660\u0662\u0663\u0668\u0664\u0668 - +\u0669\u0666\u0666 \u0661\u0663 \u0663\u0666\u0663 \u0662\u0668\u0668\u0668 - \u0635.\u0628 \u0662\u0668\u0667 \u0627\u0644\u062c\u0628\u064a\u0644 \u0663\u0661\u0669\u0665\u0661 - \u0627\u0644\u0645\u0645\u0644\u0643\u0629 \u0627\u0644\u0639\u0631\u0628\u064a\u0629 \u0627\u0644\u0633\u0639\u0648\u062f\u064a\u0629";

export default function Certificate({ data, onChange }: CertificateProps) {
  const label = (
    text: string,
    x: number,
    y: number,
    field?: keyof CertificateData,
    extraClass = "",
  ) => {
    const props = {
      className: `doc-label ${extraClass}`,
      style: { left: x, top: y } as CSSProperties,
    };

    return field ? (
      <label {...props} htmlFor={`doc-${field}`}>
        {text}
      </label>
    ) : (
      <span {...props}>{text}</span>
    );
  };

  const box = (
    field: keyof CertificateData,
    accessibleName: string,
    x: number,
    y: number,
    width: number,
    options: BoxOptions = {},
  ) => (
    <input
      id={`doc-${field}`}
      className={`doc-box${options.center ? " doc-box-center" : ""}`}
      aria-label={accessibleName}
      autoComplete="off"
      spellCheck={false}
      value={data[field]}
      onChange={(event) => onChange(field, event.target.value)}
      style={{
        left: x,
        top: y,
        width,
        height: options.height ?? 30,
        fontSize: options.fontSize ?? 20,
      }}
    />
  );

  const measurement = (
    field: "height" | "weight",
    accessibleName: string,
    unit: string,
    x: number,
    y: number,
    width: number,
  ) => (
    <div className="doc-box doc-measurement" style={{ left: x, top: y, width, height: 30 }}>
      <input
        id={`doc-${field}`}
        aria-label={accessibleName}
        autoComplete="off"
        inputMode="decimal"
        value={data[field]}
        onChange={(event) => onChange(field, event.target.value.replace(/[^\d.]/g, ""))}
        style={{ width: `${Math.max(data[field].length, 2) + 0.25}ch` }}
      />
      <span aria-hidden="true">{unit}</span>
    </div>
  );

  // The QR code is derived from the whole record, so it stays in sync with
  // every field edited inline or through the editor panel.
  const qrContent = useMemo(() => encodeCertificateQr(data), [data]);
  const previousQrContent = useRef(qrContent);
  const [qrRevision, setQrRevision] = useState(0);

  useEffect(() => {
    if (previousQrContent.current === qrContent) return;
    previousQrContent.current = qrContent;
    setQrRevision((revision) => revision + 1);
  }, [qrContent]);

  const qrDescription =
    `QR code updated with certificate details for ${data.name || "the patient"}, ` +
    `file ${data.fileNo || "number pending"}, height ${data.height || "-"} centimetres, ` +
    `weight ${data.weight || "-"} kilograms, valid until ${data.validUntil}.`;

  return (
    <article className="certificate-page" aria-label="Jubail Medicare medical check up summary certificate">
      <header className="certificate-brand" aria-label="Jubail Medicare Co.">
        <span className="sr-only">Jubail Medicare Co.</span>
        <img className="brand-symbol" src={brandSymbol} alt="" draggable={false} />
        <span className="brand-bridge" aria-hidden="true" />
        <img className="brand-arabic" src={brandArabic} alt="" draggable={false} />
        <img className="brand-english" src={brandEnglish} alt="" draggable={false} />
      </header>

      <section className="doc-intro" aria-labelledby="certificate-title">
        <h1 id="certificate-title" className="document-title">
          MEDICAL CHECK UP SUMMARY / CERTIFICATE
        </h1>
        <div
          key={`qr-${qrRevision}`}
          className="document-qr qr-refresh"
          role="img"
          aria-label={qrDescription}
          title="Live QR code - regenerates whenever any certificate detail changes"
        >
          <QRCodeSVG value={qrContent} size={116} level="M" marginSize={0} />
        </div>

        {label("TO", 0, 131, "recipient")}
        {box("recipient", "To", 87, 128, 441)}
        {label("DATE", 532, 131, "date")}
        {box("date", "Date", 626, 130, 239, { fontSize: 20 })}

        {label("FILE NO", 0, 177, "fileNo")}
        {box("fileNo", "File number", 87, 175, 145)}
        {label("CATEGORY", 268, 177, "category")}
        {box("category", "Category", 384, 176, 144)}
        {label("BLOOD GROUP", 532, 177, "bloodGroup")}
        {box("bloodGroup", "Blood group", 738, 177, 126, { center: true })}
      </section>

      <section className="doc-group personal-group scroll-reveal" aria-labelledby="personal-heading">
        <h2 id="personal-heading" className="section-heading">PERSONAL DETAILS</h2>
        {label("NAME", 0, 36, "name")}
        {box("name", "Patient name", 170, 35, 696)}
        {label("NATIONALITY", 0, 68, "nationality")}
        {box("nationality", "Nationality", 170, 67, 95, { center: true })}
        {label("AGE", 268, 68, "age")}
        {box("age", "Age", 457, 67, 242)}
        {label("SEX", 700, 68, "sex")}
        {box("sex", "Sex", 770, 67, 94)}
        {label("PASSPORT NO/IQAMA", 0, 100, "passport")}
        {box("passport", "Passport or Iqama number", 268, 99, 186, { center: true })}
        {label("DATE OF BIRTH", 457, 100, "dateOfBirth")}
        {box("dateOfBirth", "Date of birth", 700, 99, 164, { center: true })}
      </section>

      <section className="doc-group employment-group scroll-reveal" aria-labelledby="employment-heading">
        <h2 id="employment-heading" className="section-heading">EMPLOYMENT DETAILS</h2>
        {label("SPONSOR / COMPANY", 0, 36, "sponsor")}
        {box("sponsor", "Sponsor or company", 293, 34, 573)}
        {label("JOB DESCRIPTION", 0, 68, "jobDescription")}
        {box("jobDescription", "Job description", 293, 65, 290)}
        {label("CITY", 587, 68, "city")}
        {box("city", "City", 703, 65, 162)}
      </section>

      <section className="doc-group examination-group scroll-reveal" aria-labelledby="examination-heading">
        <h2 id="examination-heading" className="section-heading">MEDICAL EXAMINATION</h2>
        {label("HEIGHT", 0, 37, "height")}
        {measurement("height", "Height in centimeters", "cm", 263, 33, 116)}
        {label("WEIGHT", 417, 37, "weight")}
        {measurement("weight", "Weight in kilograms", "kg", 501, 33, 181)}
        {label("PULSE", 0, 69, "pulse")}
        {box("pulse", "Pulse", 263, 65, 116)}
        {label("B.P", 462, 69, "bloodPressure")}
        {box("bloodPressure", "Blood pressure", 501, 65, 181)}
        {label("TEMP", 710, 69, "temperature")}
        {box("temperature", "Temperature", 770, 65, 96)}
        {label("LUNGS & CHEST", 0, 100, "lungs")}
        {box("lungs", "Lungs and chest", 263, 97, 603)}
        {label("CARDIO VASCULAR", 0, 132, "cardiovascular")}
        {box("cardiovascular", "Cardiovascular", 263, 129, 603)}
        {label("NEUROLOGICAL", 0, 164, "neurological")}
        {box("neurological", "Neurological", 263, 161, 603)}
      </section>

      <section className="doc-group vision-group scroll-reveal" aria-labelledby="vision-heading">
        <h2 id="vision-heading" className="small-heading">VISION</h2>
        {label("N6 = NORMAL", 275, 1, undefined, "emphasis-label")}
        {label("N6 = NORMAL", 635, 1, undefined, "emphasis-label")}
        {label("NEAR", 89, 32)}
        {label("LEFT", 168, 32, "nearLeft")}
        {box("nearLeft", "Near vision left eye", 220, 27, 189, { fontSize: 18 })}
        {label("RIGHT", 467, 32, "nearRight")}
        {box("nearRight", "Near vision right eye", 531, 27, 333, { fontSize: 18 })}
        {label("FAR", 102, 63)}
        {label("LEFT", 168, 63, "farLeft")}
        {box("farLeft", "Far vision left eye", 220, 58, 189, { fontSize: 18 })}
        {label("RIGHT", 467, 63, "farRight")}
        {box("farRight", "Far vision right eye", 531, 58, 333, { fontSize: 18 })}
        {label("WITHOUT GLASSES", 610, 91, undefined, "emphasis-label")}
      </section>

      <section className="doc-group hearing-group scroll-reveal" aria-labelledby="hearing-heading">
        <h2 id="hearing-heading" className="small-heading">HEARING</h2>
        {label("LEFT", 168, 29, "hearingLeft")}
        {box("hearingLeft", "Hearing left ear", 221, 26, 188)}
        {label("RIGHT", 467, 29, "hearingRight")}
        {box("hearingRight", "Hearing right ear", 531, 26, 331)}
      </section>

      <section className="doc-group health-group scroll-reveal" aria-label="General health assessment">
        {label("GENERAL HEALTH CONDITION", 0, 2, "generalHealth")}
        {box("generalHealth", "General health condition", 410, 0, 455, { fontSize: 18 })}
        {box("covidSymptoms", "COVID-19 symptoms", 410, 31, 455, { fontSize: 18 })}
        {label("APPEARANCE", 0, 66, "appearance")}
        {box("appearance", "Appearance", 410, 62, 455)}
        {label("IF SUFFERING FROM ANY CHRONIC DISEASES", 0, 97, "chronicDisease")}
        {box("chronicDisease", "Chronic diseases", 410, 93, 455)}
        {label("ADDITIONAL COMMENTS IF ANY:", 0, 129, "comments")}
        {box("comments", "Additional comments", 410, 124, 455)}
      </section>

      <section className="approval-area scroll-reveal" aria-label="Certificate validity and physicians">
        <div className="validity-note">
          <span>NOTE: THIS MEDICAL FITNESS REPORT IS VALID TILL</span>
          <input
            aria-label="Report valid until"
            value={data.validUntil}
            onChange={(event) => onChange("validUntil", event.target.value)}
            spellCheck={false}
          />
        </div>
        <input
          className="doctor-name physician-name"
          aria-label="Attending physician name"
          value={data.physician}
          onChange={(event) => onChange("physician", event.target.value)}
          spellCheck={false}
        />
        <span className="doctor-role physician-role">ATTENDING PHYSICIAN</span>
        <input
          className="doctor-name director-name"
          aria-label="Medical director name"
          value={data.director}
          onChange={(event) => onChange("director", event.target.value)}
          spellCheck={false}
        />
        <span className="doctor-role director-role">MEDICAL DIRECTOR</span>
      </section>

      <SealArtwork />

      <footer className="document-footer">
        <div className="footer-rule" />
        <p className="footer-arabic" dir="rtl">{footerArabic}</p>
        <p className="footer-address">
          C.R. 2055023848 - Tel.: +966 13 363 1888 - +966 13 363 2888 - P.O. Box 287 Jubail 31951 - Kingdom of Saudi Arabia
        </p>
        <p className="footer-contact">
          E-mail: <a href="mailto:info@jubailmedicare.com">info@jubailmedicare.com</a>
          <span> - </span>
          Website: <a href="https://jubailmedicare.com/" target="_blank" rel="noreferrer">www.jubailmedicare.com</a>
        </p>
      </footer>
    </article>
  );
}