import { useEffect } from "react";

type InstallGuideProps = {
  canInstallDirectly: boolean;
  onInstall: () => void;
  onClose: () => void;
};

const chromeSteps = [
  "Open this page in Google Chrome on your Android phone.",
  "Tap the three-dot menu in the top-right corner of Chrome.",
  "Tap “Add to Home screen”, then “Install”. The JMC Certificate icon appears with your other apps.",
  "Open it from the home screen — it runs full-screen and works offline.",
];

const termuxSteps = [
  "Install Termux and Termux:Boot from F-Droid (not the outdated Play Store build).",
  "Copy this project folder onto the phone, open Termux and run: bash scripts/termux-setup.sh",
  "The script installs Node, builds the app and starts the server at http://127.0.0.1:4173.",
  "Open that address in Chrome and use “Add to Home screen” as above — it now loads from your phone itself, automatically, every time Termux starts.",
];

const apkSteps = [
  "On a computer, run: npm run build, then npx cap sync android, then cd android and ./gradlew assembleDebug.",
  "Copy android/app/build/outputs/apk/debug/app-debug.apk to your phone (USB, Drive or WhatsApp to yourself).",
  "On the phone, tap the APK file. If asked, allow “Install unknown apps” for your file manager or browser.",
  "Tap Install. The JMC Certificate app appears in the app drawer and works fully offline.",
];

export default function InstallGuide({ canInstallDirectly, onInstall, onClose }: InstallGuideProps) {
  useEffect(() => {
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, [onClose]);

  return (
    <>
      <button className="editor-backdrop" aria-label="Close install guide" onClick={onClose} />
      <section
        className="guide-panel"
        role="dialog"
        aria-modal="true"
        aria-labelledby="install-guide-title"
      >
        <div className="guide-header">
          <div>
            <span className="editor-kicker">ANDROID INSTALLATION</span>
            <h2 id="install-guide-title">Install on your phone</h2>
            <p>Three ways, easiest first. No data is lost — the certificate stays saved on the device.</p>
          </div>
          <button type="button" className="icon-button" onClick={onClose} aria-label="Close install guide">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
              <path d="M5 5l14 14M19 5L5 19" strokeLinecap="round" />
            </svg>
          </button>
        </div>

        <div className="guide-body">
          <article className="guide-card guide-card-recommended">
            <div className="guide-card-head">
              <span className="guide-badge">Easiest — 1 minute</span>
              <h3>Install straight from Chrome</h3>
            </div>
            <ol>
              {chromeSteps.map((step) => (
                <li key={step}>{step}</li>
              ))}
            </ol>
            {canInstallDirectly ? (
              <button type="button" className="print-action" onClick={onInstall}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
                  <path d="M12 3v12m0 0 4.5-4.5M12 15l-4.5-4.5" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" strokeLinecap="round" />
                </svg>
                Install now
              </button>
            ) : (
              <p className="guide-note">
                You are already in the installed app, or your browser will show the install option in its menu.
              </p>
            )}
          </article>

          <article className="guide-card">
            <div className="guide-card-head">
              <span className="guide-badge guide-badge-alt">Runs on the phone itself</span>
              <h3>Termux backend (auto-start)</h3>
            </div>
            <ol>
              {termuxSteps.map((step) => (
                <li key={step}>{step}</li>
              ))}
            </ol>
            <p className="guide-code">bash scripts/termux-setup.sh</p>
          </article>

          <article className="guide-card">
            <div className="guide-card-head">
              <span className="guide-badge guide-badge-alt">Real .apk file</span>
              <h3>Build and install the APK</h3>
            </div>
            <ol>
              {apkSteps.map((step) => (
                <li key={step}>{step}</li>
              ))}
            </ol>
            <p className="guide-note">
              Tip: enabling “Install unknown apps” is asked only once, per app that opens the file.
            </p>
          </article>
        </div>
      </section>
    </>
  );
}
