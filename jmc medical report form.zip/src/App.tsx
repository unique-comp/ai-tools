import { useCallback, useEffect, useState } from "react";
import Certificate from "./components/Certificate";

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};
import EditorPanel from "./components/EditorPanel";
import InstallGuide from "./components/InstallGuide";
import {
  certificateStorageKey,
  initialCertificate,
  type CertificateData,
} from "./certificate-data";

const PAGE_WIDTH = 1240;
const PAGE_HEIGHT = 1755;

function loadCertificate(): CertificateData {
  try {
    const saved = window.localStorage.getItem(certificateStorageKey);
    if (!saved) return initialCertificate;

    const parsed: unknown = JSON.parse(saved);
    if (!parsed || typeof parsed !== "object") return initialCertificate;

    const restored = { ...initialCertificate };
    for (const field of Object.keys(restored) as Array<keyof CertificateData>) {
      const value = (parsed as Record<string, unknown>)[field];
      if (typeof value === "string") restored[field] = value;
    }
    return restored;
  } catch {
    return initialCertificate;
  }
}

function getFitScale(width: number) {
  const gutter = width >= PAGE_WIDTH ? 0 : width >= 600 ? 24 : 16;
  return Math.min(1, (width - gutter * 2) / PAGE_WIDTH);
}

export default function App() {
  const [data, setData] = useState<CertificateData>(loadCertificate);
  const [viewportWidth, setViewportWidth] = useState(() => window.innerWidth);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [isGuideOpen, setIsGuideOpen] = useState(false);
  const [isZoomed, setIsZoomed] = useState(false);
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);
  const [isStandalone, setIsStandalone] = useState(
    () =>
      typeof window !== "undefined" &&
      (window.matchMedia("(display-mode: standalone)").matches ||
        (navigator as Navigator & { standalone?: boolean }).standalone === true),
  );

  useEffect(() => {
    const handleResize = () => setViewportWidth(window.innerWidth);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem(certificateStorageKey, JSON.stringify(data));
    } catch {
      // The document remains editable when browser storage is unavailable.
    }
  }, [data]);

  useEffect(() => {
    const handleBeforeInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    const handleInstalled = () => {
      setInstallPrompt(null);
      setIsStandalone(true);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    window.addEventListener("appinstalled", handleInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
      window.removeEventListener("appinstalled", handleInstalled);
    };
  }, []);

  useEffect(() => {
    if (!isEditorOpen && !isGuideOpen) return;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setIsEditorOpen(false);
        setIsGuideOpen(false);
      }
    };
    window.addEventListener("keydown", handleEscape);

    if (window.innerWidth > 700) {
      document.querySelector<HTMLInputElement>(".measurement-field input")?.focus();
    }

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleEscape);
    };
  }, [isEditorOpen]);

  useEffect(() => {
    if (!("IntersectionObserver" in window)) return;

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            entry.target.classList.add("has-entered");
            observer.unobserve(entry.target);
          }
        }
      },
      { threshold: 0.08 },
    );

    document.querySelectorAll(".scroll-reveal:not(.has-entered)").forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, [viewportWidth, isZoomed]);

  const updateField = useCallback((field: keyof CertificateData, value: string) => {
    setData((current) => ({ ...current, [field]: value }));
  }, []);

  const resetCertificate = () => {
    if (window.confirm("Restore all details to the sample certificate?")) {
      setData({ ...initialCertificate });
    }
  };

  const installApp = async () => {
    if (!installPrompt) return;
    await installPrompt.prompt();
    const { outcome } = await installPrompt.userChoice;
    if (outcome === "accepted") setInstallPrompt(null);
  };

  const fitScale = getFitScale(viewportWidth);
  const previewScale = isZoomed && viewportWidth < 900 ? Math.max(fitScale, 0.72) : fitScale;

  return (
    <main className="workspace">
      <div className={`paper-scroll${isZoomed ? " paper-scroll-zoomed" : ""}`}>
        <div
          className="paper-stage"
          style={{ width: PAGE_WIDTH * previewScale, height: PAGE_HEIGHT * previewScale }}
        >
          <div className="paper-scale" style={{ transform: `scale(${previewScale})` }}>
            <Certificate data={data} onChange={updateField} />
          </div>
        </div>
      </div>

      {!isEditorOpen && (
        <nav className="floating-controls" aria-label="Certificate actions">
          {viewportWidth < 900 && (
            <button
              type="button"
              className="control-button secondary-control zoom-control"
              onClick={() => setIsZoomed((zoomed) => !zoomed)}
              aria-pressed={isZoomed}
              aria-label={isZoomed ? "Fit certificate to screen" : "Zoom in on certificate"}
              title={isZoomed ? "Fit to screen" : "Zoom in"}
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
                <circle cx="10.8" cy="10.8" r="6.8" />
                <path d={isZoomed ? "M8 10.8h5.6M16 16l5 5" : "M8 10.8h5.6M10.8 8v5.6M16 16l5 5"} strokeLinecap="round" />
              </svg>
            </button>
          )}
          <button
            type="button"
            className="control-button secondary-control print-control"
            onClick={() => window.print()}
            aria-label="Print or save certificate as PDF"
            title="Print / Save PDF"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
              <path d="M6 9V3h12v6M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" strokeLinejoin="round" />
              <path d="M6 15h12v6H6zM18 12h.01" strokeLinecap="round" />
            </svg>
          </button>
          <button
            type="button"
            className="control-button secondary-control guide-control"
            onClick={() => setIsGuideOpen(true)}
            aria-label="How to install on Android"
            title="How to install on Android"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
              <circle cx="12" cy="12" r="9" />
              <path d="M9.4 9.2a2.7 2.7 0 0 1 5.3.8c0 1.8-2.7 2.3-2.7 3.8" strokeLinecap="round" />
              <path d="M12 17h.01" strokeLinecap="round" />
            </svg>
          </button>
          {installPrompt && !isStandalone && (
            <button
              type="button"
              className="control-button install-control"
              onClick={installApp}
              aria-label="Install this certificate as an app"
              title="Install app"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
                <path d="M12 3v12m0 0 4.5-4.5M12 15l-4.5-4.5" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" strokeLinecap="round" />
              </svg>
              <span className="control-label">Install app</span>
            </button>
          )}
          <button type="button" className="control-button primary-control" onClick={() => setIsEditorOpen(true)}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
              <path d="m15.5 5.5 3 3M4 20l4.5-.9L19 8.6a2.1 2.1 0 0 0-3-3L5.5 16.1 4 20Z" strokeLinejoin="round" />
            </svg>
            Edit details
          </button>
        </nav>
      )}

      {isEditorOpen && (
        <EditorPanel
          data={data}
          onChange={updateField}
          onClose={() => setIsEditorOpen(false)}
          onPrint={() => window.print()}
          onReset={resetCertificate}
        />
      )}

      {isGuideOpen && (
        <InstallGuide
          canInstallDirectly={Boolean(installPrompt) && !isStandalone}
          onInstall={installApp}
          onClose={() => setIsGuideOpen(false)}
        />
      )}
    </main>
  );
}
