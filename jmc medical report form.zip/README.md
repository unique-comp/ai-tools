# Jubail Medicare - Medical Check Up Summary / Certificate

A pixel-faithful, fully editable recreation of the Jubail Medicare Co. medical
check-up certificate, with a **live QR code** that regenerates from every field.
It runs as a normal web app, as an installable Android app (PWA or APK), and as
a local backend service in Termux.

---

## 1. Install on an Android phone (no SDK, works today)

The app is a Progressive Web App: manifest, service worker and icons are
bundled, so Chrome can install it and run it offline.

```bash
npm install
npm run build
npm run preview          # or: node scripts/serve.mjs
```

Open the URL in Chrome on the phone, then **menu -> Add to Home screen ->
Install** (or use the in-app **Install app** button that appears automatically).
The installed app opens in its own standalone window with no browser chrome,
works offline, and stores edited certificates on the device (localStorage).

---

## 2. Termux backend that starts automatically

From the project folder inside Termux:

```bash
bash scripts/termux-setup.sh
```

The script installs Node.js, builds `dist/` if needed and registers a background
service (runit via `termux-services`, with a `~/.bashrc` fallback), so
`http://127.0.0.1:4173` is up every time Termux starts.

| Command | Purpose |
| --- | --- |
| `sv status jmc-certificate` | check the service |
| `sv down jmc-certificate` / `sv up ...` | stop / start |
| `HOST=0.0.0.0 node scripts/serve.mjs` | serve on the LAN (`http://<phone-ip>:4173`) |
| `PORT=8080 node scripts/serve.mjs` | different port |
| `node scripts/serve.mjs` | manual foreground run |

Then install it from Chrome as in step 1 - the home-screen icon now points at
the Termux backend and keeps working offline via the service worker.

---

## 3. Build a real APK (Capacitor)

The Android project is already scaffolded in `android/` and synced with the
built web assets.

```bash
npm run build
npx cap sync android              # copies dist/ into the Android project
cd android
./gradlew assembleDebug           # -> android/app/build/outputs/apk/debug/app-debug.apk
adb install app/build/outputs/apk/debug/app-debug.apk
```

Release build (signed):

```bash
./gradlew assembleRelease         # uses android/app/key.properties if present
```

Requirements: JDK 17 and the Android SDK (Android Studio or `sdkmanager`), or
Android Studio itself (`npx cap open android`). On Termux a full Gradle/SDK
toolchain is possible (`pkg install openjdk-17`) but building on a PC is much
faster.

**APK + Termux variant:** uncomment the `server` block in
`capacitor.config.ts` (`http://127.0.0.1:4173`), rebuild with
`npm run build && npx cap sync android`, and the APK will load the live server
started in step 2 instead of the bundled copy.

---

## 4. CI build (optional)

`.github/workflows/build-apk.yml` builds the web app and the debug APK on every
push, so you can download `app-debug.apk` from the workflow artifacts without
installing anything locally.

---

## Editing the certificate

- Click any outlined field directly on the document to type in it.
- **Edit details** opens the panel with dedicated **Height** and **Weight**
  controls plus every other field.
- Values save to the browser automatically and are restored on next launch.
- The QR code re-encodes the whole record after each change (verifiable with any
  QR scanner).
- **Print / Save PDF** outputs a single A4 page.

## Structure

```
src/
  App.tsx                    workspace, scaling, install prompt, service worker hookup
  certificate-data.ts        sample record + QR payload encoder
  components/Certificate.tsx document markup and every editable field
  components/EditorPanel.tsx side editor (height/weight + all fields)
  components/SealArtwork.tsx vector stamps and signatures
  assets/logoAssets.ts       brand artwork embedded as data URIs (offline-safe)
scripts/
  serve.mjs                  dependency-free static server for dist/
  termux-setup.sh            Termux install + auto-start service
public/
  manifest.webmanifest       PWA manifest
  sw.js                      offline cache
  icons/                     192/512/maskable app icons
capacitor.config.ts          Android wrapper configuration
android/                     Capacitor Android project (ready for Gradle)
```
