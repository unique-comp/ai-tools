#!/data/data/com.termux/files/usr/bin/bash
# Sets up the Jubail Medicare certificate in Termux:
#   - installs Node.js, dependencies and the build
#   - serves dist/ in the background, automatically on every Termux start
#   - prints the URL to install as a home-screen app
#
# Usage:  bash scripts/termux-setup.sh
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
SVC_NAME="jmc-certificate"
PORT_NUM="${PORT:-4173}"

if [ -z "${TERMUX_VERSION:-}" ] && [ ! -d "/data/data/com.termux" ]; then
  echo "This script targets Termux (TERMUX_VERSION not detected)."
  echo "Elsewhere run:  npm install && npm run build && node scripts/serve.mjs"
  exit 1
fi

echo "[1/5] Node.js"
if ! command -v node >/dev/null 2>&1; then
  pkg update -y || true
  pkg install -y nodejs-lts || pkg install -y nodejs
fi
node --version

echo "[2/5] Dependencies"
cd "$APP_DIR"
[ -d node_modules ] || npm install

echo "[3/5] Build"
if [ ! -f dist/index.html ]; then
  npm run build
fi

echo "[4/5] Background service"
RUN_FILE_CONTENT='#!/data/data/com.termux/files/usr/bin/bash -e
exec 2>&1
cd "'"${APP_DIR}"'"
exec node scripts/serve.mjs'

if ! command -v sv >/dev/null 2>&1; then
  pkg install -y termux-services || true
fi

AUTO_START=""
if command -v sv >/dev/null 2>&1; then
  mkdir -p "$PREFIX/var/sv/$SVC_NAME" "$PREFIX/var/service"
  printf '%s\n' "$RUN_FILE_CONTENT" > "$PREFIX/var/sv/$SVC_NAME/run"
  chmod 755 "$PREFIX/var/sv/$SVC_NAME/run"
  ln -sfn "$PREFIX/var/sv/$SVC_NAME" "$PREFIX/var/service/$SVC_NAME"
  sv up "$SVC_NAME" 2>/dev/null || true
  AUTO_START="termux-services - starts automatically in the background"
else
  BASHRC="$HOME/.bashrc"
  MARKER="# jmc-certificate-server"
  if ! grep -qF "$MARKER" "$BASHRC" 2>/dev/null; then
    {
      echo "$MARKER"
      echo "pgrep -f 'scripts/serve.mjs' >/dev/null 2>&1 || (cd '$APP_DIR' && nohup node scripts/serve.mjs >/dev/null 2>&1 &)"
    } >> "$BASHRC"
  fi
  (cd "$APP_DIR" && nohup node scripts/serve.mjs >/dev/null 2>&1 &)
  AUTO_START="$BASHRC entry - starts when a Termux session opens"
fi

echo "[5/5] Ready"
echo "  URL        : http://127.0.0.1:$PORT_NUM"
echo "  Auto start : $AUTO_START"
echo "  Install    : open the URL in Chrome -> menu -> Add to Home screen"
echo "  LAN access : HOST=0.0.0.0 node scripts/serve.mjs"
echo "  Status     : sv status $SVC_NAME   |   Stop: sv down $SVC_NAME"
