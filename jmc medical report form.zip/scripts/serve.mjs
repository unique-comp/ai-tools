#!/usr/bin/env node
/**
 * Minimal static server for the built certificate (dist/).
 *
 *   node scripts/serve.mjs              # http://127.0.0.1:4173
 *   PORT=8080 node scripts/serve.mjs    # custom port
 *   HOST=0.0.0.0 node scripts/serve.mjs # reachable from the LAN
 *
 * Written for Termux: no dependencies, keeps running in the background under
 * runit (termux-services) or a boot script.
 */
import { createServer } from "node:http";
import { createReadStream } from "node:fs";
import { stat } from "node:fs/promises";
import { extname, join, normalize, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = resolve(fileURLToPath(new URL("../dist", import.meta.url)));
const PORT = Number(process.env.PORT || 4173);
const HOST = process.env.HOST || "127.0.0.1";

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".webmanifest": "application/manifest+json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".woff2": "font/woff2",
  ".map": "application/json; charset=utf-8",
  ".txt": "text/plain; charset=utf-8",
};

async function resolveFile(urlPath) {
  const decoded = decodeURIComponent(urlPath.split("?")[0]);
  const relative = normalize(decoded).replace(/^(\.\.[/\\])+/, "");
  let filePath = join(ROOT, relative);

  if (!filePath.startsWith(ROOT)) return null;

  try {
    const info = await stat(filePath);
    if (info.isDirectory()) filePath = join(filePath, "index.html");
    return filePath;
  } catch {
    const withIndex = join(ROOT, relative, "index.html");
    try {
      await stat(withIndex);
      return withIndex;
    } catch {
      return null;
    }
  }
}

const server = createServer((req, res) => {
  resolveFile(req.url || "/").then((filePath) => {
    if (!filePath) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      res.end("Not found");
      return;
    }

    res.writeHead(200, {
      "Content-Type": MIME[extname(filePath).toLowerCase()] || "application/octet-stream",
      "Cache-Control": filePath.endsWith("index.html") ? "no-cache" : "public, max-age=3600",
      "Service-Worker-Allowed": "/",
    });

    if (req.method === "HEAD") {
      res.end();
      return;
    }
    createReadStream(filePath).pipe(res);
  });
});

server.listen(PORT, HOST, () => {
  console.log(`JMC certificate running at http://${HOST}:${PORT}`);
  console.log(`Serving: ${ROOT}`);
});
